declare module "*.module.scss";
declare module "haversine-geolocation";
declare module "react-google-maps";
