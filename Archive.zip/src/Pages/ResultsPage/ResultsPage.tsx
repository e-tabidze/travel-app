import React, { useState, useEffect } from "react";
import { Container } from "@mui/material";
import {
  withGoogleMap,
  withScriptjs,
  GoogleMap,
  Marker,
} from "react-google-maps";
import { useSearchParams } from "react-router-dom";
import { IResultObj } from "../../Interfaces/Interfaces";
import { getDirections } from "../../Services/cities.services";

import "./map.css";

const ResultsPage = () => {
  const [tripProps, setTripProps] = useState<IResultObj>();
  const [search] = useSearchParams();

  useEffect(() => {
    handleSetParams();
  }, []);

  useEffect(() => {
    if (tripProps) {
      handleGetDirections();
    }
  }, [tripProps]);

  const handleSetParams = () => {
    let obj = Object.fromEntries(search);
    obj.city_of_origin = JSON.parse(obj.city_of_origin);
    obj.city_of_destination = JSON.parse(obj.city_of_destination);
    obj.waypoints_city = JSON.parse(obj.waypoints_string);
    // @ts-ignore
    obj.waypoints_city = obj.waypoints_city.map((waypoint: string) =>
      JSON.parse(waypoint)
    );
    obj.number_of_people = JSON.parse(obj.number_of_people);
    // @ts-ignore
    setTripProps(obj);
  };

  const getAveragePosition = () => {
    let originCity = {
      lat: parseInt(tripProps?.city_of_origin.latitude),
      lng: parseInt(tripProps?.city_of_origin.longitude),
    };
    let destCity = {
      lat: parseInt(tripProps?.city_of_destination.latitude),
      lng: parseInt(tripProps?.city_of_destination.longitude),
    };

    let average = {
      lat: (originCity.lat + destCity.lat) / 2,
      lng: (destCity.lng + destCity.lng) / 2,
    };
    return average;
  };

  const handleGetDirections = async () => {
    let queryString = "?";

    queryString += `origin=${tripProps?.city_of_origin.latitude}${tripProps?.city_of_origin.longitude}`;
    queryString += `&destination=${tripProps?.city_of_destination.latitude}${tripProps?.city_of_destination.longitude}&`;

    tripProps?.waypoints_city.forEach(
      (waypoint) =>
        (queryString += `${waypoint.latitude}${waypoint.longitude} |`)
    );
    queryString += `&key=AIzaSyAHNyZoDCvjwtvM31xIRn1mWG6ma2KQvDE`;
    let result = await getDirections(queryString);
    console.log(result, '[DIRECTIONS]');

  };

  return (
    <Container maxWidth="lg">
      {/* @ts-ignore */}
      {tripProps && (
        // @ts-ignore
        <GoogleMap defaultZoom={5} defaultCenter={getAveragePosition()}>
          <Marker
            position={{
              lat: parseInt(tripProps.city_of_origin.latitude),
              lng: parseInt(tripProps?.city_of_origin.longitude),
            }}
          />
          <Marker
            position={{
              lat: parseInt(tripProps?.city_of_destination.latitude),
              lng: parseInt(tripProps?.city_of_destination.longitude),
            }}
          />
          {tripProps.waypoints_city.map((point, index) => (
            <Marker
              key={index}
              position={{
                lat: parseInt(point.latitude),
                lng: parseInt(point.longitude),
              }}
            />
          ))}
        </GoogleMap>
      )}
    </Container>
  );
};

const MapComponent = withScriptjs(withGoogleMap(ResultsPage));

// export default ResultsPage;

export default () => (
  <MapComponent
    googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHNyZoDCvjwtvM31xIRn1mWG6ma2KQvDE"
    loadingElement={<div style={{ height: `100%` }} />}
    containerElement={<div style={{ height: `400px`, width: "500px" }} />}
    mapElement={<div style={{ height: `100%` }} />}
  />
);
